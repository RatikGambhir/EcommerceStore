namespace API.Entities.Order
{
    public enum OrderStatus
    {
        Pending,
        PaymentRecieved,

        PaymentFailed
    }
}
